import { motion } from "framer-motion";

/**
 * Signature-style "Kanish" wordmark that draws itself on scroll into view.
 * SVG stroke animation — GPU-friendly, no layout thrash.
 */
export function SignatureDraw() {
  return (
    <svg
      viewBox="0 0 1200 260"
      className="w-full h-auto text-foreground"
      preserveAspectRatio="xMidYMid meet"
      role="img"
      aria-label="Kanish signature"
    >
      <defs>
        <linearGradient id="sig-grad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="var(--color-accent-ink)" />
          <stop offset="100%" stopColor="var(--color-accent-2)" />
        </linearGradient>
      </defs>
      <motion.text
        x="50%"
        y="60%"
        textAnchor="middle"
        dominantBaseline="middle"
        fontFamily="var(--font-display)"
        fontSize="220"
        fill="none"
        stroke="url(#sig-grad)"
        strokeWidth="1.4"
        style={{ letterSpacing: "-0.03em" }}
        initial={{ pathLength: 0, opacity: 0 }}
        whileInView={{ pathLength: 1, opacity: 1 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ pathLength: { duration: 2.4, ease: [0.22, 1, 0.36, 1] }, opacity: { duration: 0.6 } }}
      >
        Kanish.
      </motion.text>
    </svg>
  );
}
