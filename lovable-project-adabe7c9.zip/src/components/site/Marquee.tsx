import { Reveal } from "./motion-primitives";

const ITEMS = [
  "Business Websites",
  "Landing Pages",
  "Admin Dashboards",
  "Custom CRMs",
  "React Applications",
  "React Native Apps",
  "Backend APIs",
  "Automation",
  "SEO Optimization",
  "Performance Audits",
];

export function Marquee() {
  const row = [...ITEMS, ...ITEMS];
  return (
    <section aria-hidden className="relative py-14 border-y border-hairline overflow-hidden">
      <Reveal>
        <div className="flex whitespace-nowrap animate-marquee gap-12 will-change-transform">
          {row.map((t, i) => (
            <div
              key={i}
              className="flex items-center gap-12 font-display text-3xl md:text-4xl text-muted-foreground transition-colors hover:text-foreground"
            >
              <span>{t}</span>
              <span className="text-accent">◆</span>
            </div>
          ))}
        </div>
      </Reveal>
    </section>
  );
}
