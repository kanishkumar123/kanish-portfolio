import { Reveal } from "./motion-primitives";

const POINTS = [
  { k: "2+", v: "Years shipping production apps" },
  { k: "2,000+", v: "Users on live products" },
  { k: "70%", v: "Manual work removed via automation" },
  { k: "95+", v: "Lighthouse targets, consistently hit" },
];

const TRUST = [
  "Production Applications",
  "End-to-End Development",
  "Mobile + Web Expertise",
  "Fast Delivery",
  "SEO Optimized",
  "Responsive by Default",
  "Performance Focused",
  "Secure Development",
  "Clean Code",
  "Scalable Architecture",
];

export function About() {
  return (
    <section id="about" className="relative py-28 md:py-40 border-t border-hairline cv-auto">
      <div className="container-x">
        <div className="grid gap-14 md:grid-cols-12">
          <Reveal className="md:col-span-7">
            <p className="section-label"><span className="section-label-dot" /> About</p>
            <h2 className="mt-6 text-6xl md:text-8xl leading-[0.95]">
              <span className="font-display italic">A studio of one,</span><br />
              <span className="font-sans font-black uppercase tracking-[-0.02em] text-gradient-accent">wired like a team.</span>
            </h2>
            <p className="mt-8 max-w-xl text-lg text-muted-foreground leading-relaxed">
              I'm Kanish — a full stack &amp; mobile developer based in Salem, India. For the
              last two years I've shipped production products for colleges, manufacturers,
              healthcare clinics, and SaaS founders. You get design, engineering, and
              deployment through a single point of contact — with the discipline of a
              senior team.
            </p>
            <div className="mt-10 flex flex-wrap gap-2">
              {TRUST.map((t) => (
                <span key={t} className="chip">{t}</span>
              ))}
            </div>
          </Reveal>

          <Reveal className="md:col-span-5" delay={0.1}>
            <div className="grid grid-cols-2 gap-px overflow-hidden rounded-3xl border border-hairline surface-tint">
              {POINTS.map((p) => (
                <div key={p.v} className="bg-background p-6 md:p-8">
                  <div className="text-3xl md:text-4xl font-semibold tracking-tight text-accent tabular-nums">
                    {p.k}
                  </div>
                  <div className="mt-2 text-xs md:text-sm text-muted-foreground">{p.v}</div>
                </div>
              ))}
            </div>

            <div className="mt-6 rounded-3xl hairline bg-card p-6 md:p-8">
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-accent/10 text-accent">
                  <span className="h-2 w-2 rounded-full bg-accent animate-pulse-dot" />
                </span>
                <div>
                  <div className="text-sm">Currently available for one new client</div>
                  <div className="text-xs text-muted-foreground">Q1 2026 · Salem, Tamil Nadu</div>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
