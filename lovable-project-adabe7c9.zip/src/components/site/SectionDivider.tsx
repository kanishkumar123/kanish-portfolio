import { motion } from "framer-motion";

export function SectionDivider({ label }: { label?: string }) {
  return (
    <div aria-hidden className="container-x py-6">
      <div className="relative flex items-center gap-4">
        <motion.span
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
          className="h-px flex-1 origin-left bg-gradient-to-r from-transparent via-foreground/20 to-transparent"
        />
        {label && (
          <span className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
            {label}
          </span>
        )}
        <motion.span
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1], delay: 0.1 }}
          className="h-px flex-1 origin-right bg-gradient-to-r from-transparent via-foreground/20 to-transparent"
        />
      </div>
    </div>
  );
}
