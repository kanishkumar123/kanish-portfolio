import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { ArrowUpRight, Mail } from "lucide-react";
import { easeApple } from "./motion-primitives";

export function CTA() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.94, 1, 1.04]);
  const y = useTransform(scrollYProgress, [0, 1], [40, -40]);

  return (
    <section id="contact" ref={ref} className="relative py-28 md:py-40 cv-auto">
      <div className="container-x">
        <motion.div
          style={{ scale, y }}
          className="relative overflow-hidden rounded-[36px] border border-hairline p-10 md:p-20 bg-[#0a0a0a] text-white"
        >
          <div className="pointer-events-none absolute inset-0 -z-10">
            <div
              className="absolute inset-0"
              style={{
                background:
                  "radial-gradient(80% 60% at 20% 10%, rgba(94,234,212,0.30), transparent 60%), radial-gradient(80% 60% at 80% 90%, rgba(139,92,246,0.32), transparent 60%)",
              }}
            />
            <div className="absolute inset-0 bg-[linear-gradient(180deg,transparent,rgba(0,0,0,0.4))]" />
          </div>

          <motion.p
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: easeApple }}
            className="section-label !text-white/70"
          >
            <span className="section-label-dot" /> Let's build
          </motion.p>

          <motion.h2
            initial={{ opacity: 0, y: 20, filter: "blur(8px)" }}
            whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            viewport={{ once: true }}
            transition={{ duration: 1, ease: easeApple, delay: 0.1 }}
            className="mt-6 max-w-5xl text-6xl md:text-9xl leading-[0.9]"
          >
            <span className="font-display italic">Have an idea worth shipping?</span>
            <br />
            <span className="font-sans font-black uppercase tracking-[-0.025em] text-gradient-accent">Let's make it real.</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, ease: easeApple, delay: 0.2 }}
            className="mt-8 max-w-xl text-lg text-white/70"
          >
            Tell me about your product, your users, and the outcome you need. I'll come
            back within 24 hours with a plan.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, ease: easeApple, delay: 0.3 }}
            className="mt-10 flex flex-col sm:flex-row gap-3"
          >
            <a
              href="mailto:hello@kanish.dev"
              className="inline-flex items-center gap-2 rounded-full bg-white text-[#0a0a0a] px-5 py-3 text-sm font-medium transition-transform hover:-translate-y-px"
            >
              hello@kanish.dev <ArrowUpRight className="h-4 w-4" />
            </a>
            <a
              href="mailto:hello@kanish.dev"
              className="inline-flex items-center gap-2 rounded-full border border-white/20 px-5 py-3 text-sm font-medium text-white hover:bg-white/5 transition-colors"
            >
              <Mail className="h-4 w-4" /> Email me directly
            </a>
          </motion.div>

          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 text-sm text-white/60">
            {[
              ["Response time", "Under 24h"],
              ["Availability", "Q1 2026"],
              ["Based in", "Salem, India"],
              ["Working", "Worldwide"],
            ].map(([k, v]) => (
              <div key={k}>
                <div className="text-[11px] uppercase tracking-widest text-white/50">{k}</div>
                <div className="mt-1 text-white">{v}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
