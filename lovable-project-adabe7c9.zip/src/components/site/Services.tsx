import { motion } from "framer-motion";
import { Reveal, easeApple } from "./motion-primitives";
import {
  Globe,
  LayoutDashboard,
  Smartphone,
  Server,
  Database,
  Gauge,
  RefreshCw,
  Search,
  Wrench,
  Sparkles,
  Boxes,
  ArrowUpRight,
} from "lucide-react";

const SERVICES = [
  { icon: Globe, title: "Business Websites", copy: "Fast, on-brand marketing sites engineered to convert visitors into enquiries." },
  { icon: Sparkles, title: "Landing Pages", copy: "High-signal launch pages built around a single conversion goal." },
  { icon: LayoutDashboard, title: "Admin Dashboards", copy: "Role-based dashboards that turn messy data into daily operational clarity." },
  { icon: Boxes, title: "React Applications", copy: "Complex, stateful web apps with clean architecture and pixel-honest UI." },
  { icon: Smartphone, title: "Mobile Apps", copy: "React Native apps shipped to iOS and Android from a single codebase." },
  { icon: Server, title: "Backend APIs", copy: "Type-safe REST and webhook APIs that scale with your product." },
  { icon: Database, title: "Database Design", copy: "Relational schemas designed to stay fast and simple as you grow." },
  { icon: Gauge, title: "Performance Optimization", copy: "Real-world Lighthouse and Core Web Vitals gains, not just synthetic scores." },
  { icon: RefreshCw, title: "Website Redesign", copy: "Modernize dated sites without losing SEO equity or existing customers." },
  { icon: Search, title: "SEO Optimization", copy: "Technical SEO, structured data, and content architecture built in from day one." },
  { icon: Wrench, title: "Maintenance", copy: "Reliable ongoing support so your product keeps compounding value." },
];

export function Services() {
  return (
    <section id="services" className="relative py-28 md:py-40">
      <div className="container-x">
        <div className="grid gap-10 md:grid-cols-12 md:items-end">
          <Reveal className="md:col-span-6">
            <p className="section-label"><span className="section-label-dot" /> Services</p>
            <h2 className="mt-6 text-6xl md:text-8xl leading-[0.95]">
              <span className="font-sans font-black uppercase tracking-[-0.02em]">One studio.</span><br />
              <span className="font-display italic text-gradient-accent">everything to ship.</span>
            </h2>
          </Reveal>
          <Reveal className="md:col-span-5 md:col-start-8" delay={0.1}>
            <p className="text-lg text-muted-foreground max-w-md">
              From first sketch to production deployment. You get one accountable partner
              across design, engineering, mobile, backend, and performance — not a
              handoff chain.
            </p>
          </Reveal>
        </div>

        <div className="mt-16 md:mt-24 grid grid-cols-1 gap-px overflow-hidden rounded-3xl border border-hairline surface-tint sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s, i) => (
            <ServiceCard key={s.title} {...s} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ServiceCard({
  icon: Icon,
  title,
  copy,
  index,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  copy: string;
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, filter: "blur(6px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.8, ease: easeApple, delay: (index % 3) * 0.05 }}
      className="group relative bg-background p-8 md:p-10 transition-colors hover:surface-tint"
    >
      <div className="flex items-start justify-between">
        <div className="grid h-11 w-11 place-items-center rounded-2xl hairline surface-tint text-accent">
          <Icon className="h-5 w-5" />
        </div>
        <ArrowUpRight className="h-4 w-4 text-muted-foreground opacity-0 -translate-x-1 translate-y-1 transition-all duration-500 group-hover:opacity-100 group-hover:translate-x-0 group-hover:translate-y-0" />
      </div>
      <h3 className="mt-8 text-xl font-medium tracking-tight">{title}</h3>
      <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{copy}</p>
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-accent/40 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
    </motion.div>
  );
}
