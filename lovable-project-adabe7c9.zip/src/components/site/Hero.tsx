import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { ArrowUpRight, ArrowDown } from "lucide-react";
import { easeApple } from "./motion-primitives";
import { CinematicBackdrop } from "./CinematicBackdrop";
import { LiveClock } from "./LiveClock";

// Dual-typography headline — sans display (uppercase, tight-tracked)
// alternating with serif italic. This pairing is the site's signature.
const HEADLINE: { text: string; kind: "sans" | "serif" }[] = [
  { text: "SOFTWARE", kind: "sans" },
  { text: "for teams", kind: "serif" },
  { text: "THAT SHIP.", kind: "sans" },
];

// Timing: word-by-word cinematic entrance, ~2.2s total.
const WORD_STAGGER = 0.14;
const HEADLINE_DELAY = 0.55;

export function Hero() {
  const ref = useRef<HTMLElement>(null);

  // The section is TALL (pinned via sticky) so we get scroll range for the
  // cinematic backdrop. Content stays vertically centered in the viewport.
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const contentY = useTransform(scrollYProgress, [0, 1], [0, 60]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.55, 0.85], [1, 1, 0]);
  const contentBlur = useTransform(scrollYProgress, [0, 1], ["blur(0px)", "blur(6px)"]);

  return (
    <section
      ref={ref}
      className="relative isolate h-[220svh] w-full"
      aria-label="Introduction"
    >
      <div className="sticky top-0 flex h-[100svh] w-full flex-col justify-center overflow-hidden">
        <CinematicBackdrop targetRef={ref} />
        <motion.div
          style={{ y: contentY, opacity: contentOpacity, filter: contentBlur }}
          className="container-x"
        >
          {/* Eyebrow — fades in from darkness */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease: easeApple, delay: 0.25 }}
            className="section-label"
          >
            <span className="section-label-dot" />
            Available Q1 · Salem, IN · <LiveClock />
          </motion.div>

          {/* Headline — word-by-word slide + blur */}
          <h1 className="mt-8 md:mt-12 leading-[0.88] tracking-[-0.03em] text-[16vw] sm:text-[13vw] md:text-[11vw] lg:text-[9.5vw]">
            {HEADLINE.map((line, i) => (
              <span key={line.text} className="block overflow-hidden">
                <motion.span
                  initial={{ y: "110%", opacity: 0, filter: "blur(14px)" }}
                  animate={{ y: "0%", opacity: 1, filter: "blur(0px)" }}
                  transition={{
                    duration: 1.15,
                    ease: easeApple,
                    delay: HEADLINE_DELAY + i * WORD_STAGGER,
                  }}
                  className={
                    "inline-block will-change-transform " +
                    (line.kind === "sans"
                      ? "font-sans font-black uppercase tracking-[-0.02em]"
                      : "font-display italic text-gradient-accent pr-2")
                  }
                >
                  {line.text}
                </motion.span>
              </span>
            ))}
          </h1>

          <div className="mt-12 md:mt-16 grid gap-10 md:grid-cols-12 md:items-end">
            <motion.p
              initial={{ opacity: 0, y: 20, filter: "blur(8px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              transition={{ duration: 1.1, ease: easeApple, delay: 1.35 }}
              className="md:col-span-6 lg:col-span-5 text-lg md:text-xl text-muted-foreground max-w-xl"
            >
              I'm <span className="text-foreground">Kanish Kumar</span> — an independent full stack &amp; mobile developer.
              I design and build production-ready web apps, dashboards, and mobile products for
              businesses, startups, and SaaS founders.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.1, ease: easeApple, delay: 1.55 }}
              className="md:col-span-6 lg:col-span-7 flex flex-col sm:flex-row sm:items-end sm:justify-end gap-4"
            >
              <a href="#work" className="btn-ghost">
                See selected work
                <ArrowDown className="h-4 w-4" />
              </a>
              <a href="#contact" className="btn-primary">
                Start a project
                <ArrowUpRight className="h-4 w-4" />
              </a>
            </motion.div>
          </div>

          {/* Metric strip */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.1, ease: easeApple, delay: 1.75 }}
            className="mt-16 md:mt-24 grid grid-cols-2 gap-px overflow-hidden rounded-3xl border border-hairline bg-foreground/[0.04] md:grid-cols-4"
          >
            {[
              { k: "2+", v: "Years shipping production" },
              { k: "2,000+", v: "Users served across products" },
              { k: "70%", v: "Manual work eliminated" },
              { k: "E2E", v: "Design → deploy" },
            ].map((m) => (
              <div key={m.v} className="bg-background/70 backdrop-blur-md p-6 md:p-8">
                <div className="text-3xl md:text-4xl font-semibold tracking-tight tabular-nums">
                  {m.k}
                </div>
                <div className="mt-2 text-xs md:text-sm text-muted-foreground">
                  {m.v}
                </div>
              </div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
