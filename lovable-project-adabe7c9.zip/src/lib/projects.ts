import scholarshipImg from "@/assets/projects/scholarship.jpg";
import corporateImg from "@/assets/projects/corporate.jpg";
import studentImg from "@/assets/projects/student.jpg";
import clinicImg from "@/assets/projects/clinic.jpg";

export type Project = {
  slug: string;
  name: string;
  tagline: string;
  category: string;
  year: string;
  duration: string;
  role: string;
  cover: string; // gradient css overlay
  image: string; // background image url
  accent: string;
  liveUrl?: string;
  problem: string;
  goal: string;
  solution: string;
  features: string[];
  stack: string[];
  process: string[];
  challenges: string[];
  results: { label: string; value: string }[];
  impact: string;
};

export const projects: Project[] = [
  {
    slug: "scholarship-portal",
    name: "Scholarship Portal",
    tagline: "A statewide portal serving 2,000+ applicants end-to-end.",
    category: "Government · EdTech",
    year: "2024",
    duration: "10 weeks",
    role: "Full Stack Developer",
    accent: "#5EEAD4",
    image: scholarshipImg,
    cover:
      "radial-gradient(120% 80% at 10% 10%, rgba(94,234,212,0.35), transparent 60%), radial-gradient(80% 80% at 90% 90%, rgba(139,92,246,0.35), transparent 60%), linear-gradient(180deg,#0a1412 0%, #0a0a1a 100%)",
    liveUrl: "#",
    problem:
      "The existing paper-based application flow could not scale. Applicants faced long queues, staff processed submissions manually, and there was no audit trail for approvals.",
    goal: "Ship a secure digital portal that could handle thousands of applicants concurrently with a transparent, reviewable workflow.",
    solution:
      "Built a role-based portal with multi-step applications, document upload, status tracking, an admin review dashboard, and automated notifications.",
    features: [
      "Multi-step application wizard with autosave",
      "Document upload with virus scanning",
      "Role-based admin review workflow",
      "Automated email + SMS notifications",
      "Full audit log and export to CSV",
      "Applicant status tracking dashboard",
    ],
    stack: ["React", "Node.js", "Express", "PostgreSQL", "TailwindCSS", "AWS S3"],
    process: [
      "Stakeholder interviews and workflow mapping",
      "Wireframes and prototype validation",
      "Schema design, API contracts, RBAC model",
      "Iterative delivery with weekly demos",
      "Load testing and hardening pre-launch",
    ],
    challenges: [
      "Handling 2,000+ concurrent submissions during deadline week",
      "Guaranteeing zero data loss on flaky mobile connections",
      "Building a review UI staff could learn in under 15 minutes",
    ],
    results: [
      { label: "Applicants served", value: "2,000+" },
      { label: "Manual work reduced", value: "70%" },
      { label: "Avg. review time", value: "-65%" },
      { label: "Uptime during launch", value: "99.98%" },
    ],
    impact:
      "Eliminated paperwork bottlenecks, cut processing time by two thirds, and gave leadership real-time visibility into applications for the first time.",
  },
  {
    slug: "manufacturing-corporate",
    name: "Corporate Manufacturing Site",
    tagline: "A cinematic brand presence for a heavy-industry manufacturer.",
    category: "Corporate · Manufacturing",
    year: "2024",
    duration: "6 weeks",
    role: "Design + Full Stack",
    accent: "#8B5CF6",
    image: corporateImg,
    cover:
      "radial-gradient(120% 80% at 90% 10%, rgba(245,158,11,0.28), transparent 60%), radial-gradient(80% 80% at 10% 90%, rgba(139,92,246,0.30), transparent 60%), linear-gradient(180deg,#150d05 0%, #0a0a0a 100%)",
    liveUrl: "#",
    problem:
      "A legacy WordPress site loaded in over 8 seconds and no longer reflected the scale of the company's operations.",
    goal: "Rebuild the brand online as a premium, fast, SEO-friendly experience that generates qualified enquiries.",
    solution:
      "Delivered a bespoke React site with a headless CMS, product catalog, case studies, and an enquiry pipeline connected to their CRM.",
    features: [
      "Headless CMS for non-technical editors",
      "Product catalog with search & filters",
      "Global enquiry form → CRM webhook",
      "Case studies with animated hero",
      "Localized meta + structured data for SEO",
    ],
    stack: ["React", "Vite", "TailwindCSS", "Framer Motion", "Sanity CMS", "Vercel"],
    process: [
      "Brand + audience workshop",
      "Content architecture and IA",
      "Design system and motion language",
      "Progressive build with editor training",
    ],
    challenges: [
      "Migrating years of legacy content without breaking SEO",
      "Balancing cinematic motion with corporate tone",
    ],
    results: [
      { label: "Lighthouse score", value: "98" },
      { label: "Load time", value: "-72%" },
      { label: "Qualified leads / mo", value: "3.4×" },
    ],
    impact:
      "Positioned the manufacturer as a modern, technology-forward operation and became a measurable driver of B2B enquiries within the first quarter.",
  },
  {
    slug: "student-management",
    name: "Student Management System",
    tagline: "An internal platform that runs an entire college's operations.",
    category: "EdTech · Internal Tools",
    year: "2023",
    duration: "12 weeks",
    role: "Full Stack Developer",
    accent: "#5EEAD4",
    image: studentImg,
    cover:
      "radial-gradient(120% 80% at 50% 0%, rgba(99,102,241,0.35), transparent 60%), radial-gradient(80% 80% at 50% 100%, rgba(94,234,212,0.22), transparent 60%), linear-gradient(180deg,#0a1428 0%, #0a0a18 100%)",
    liveUrl: "#",
    problem:
      "Attendance, marks, fees, and hostel data lived in disconnected Excel files, causing constant reconciliation issues.",
    goal: "Unify every core operation into one role-based platform used by faculty, staff, and students.",
    solution:
      "Designed a modular admin dashboard covering attendance, gradebooks, fees, timetables, and student profiles with granular permissions.",
    features: [
      "Role-based dashboards (admin / faculty / student)",
      "Attendance and gradebook modules",
      "Fee tracking and receipts",
      "Timetable and hostel management",
      "PDF reports and bulk import/export",
    ],
    stack: ["React", "Node.js", "MongoDB", "TailwindCSS", "Chart.js", "JWT"],
    process: [
      "Audited existing spreadsheets and forms",
      "Defined modules with department heads",
      "Rolled out module-by-module with training",
    ],
    challenges: [
      "Migrating years of unstructured Excel data",
      "Designing permissions for six distinct roles",
    ],
    results: [
      { label: "Manual reports removed", value: "40+" },
      { label: "Time saved / week", value: "60 hrs" },
      { label: "Adoption in month 1", value: "100%" },
    ],
    impact:
      "Replaced dozens of spreadsheets with a single source of truth and became the operational backbone of the institution.",
  },
  {
    slug: "clinic-mobile-app",
    name: "Clinic Companion App",
    tagline: "A React Native app for patients and staff in a private clinic.",
    category: "Healthcare · Mobile",
    year: "2024",
    duration: "8 weeks",
    role: "Mobile + Backend",
    accent: "#8B5CF6",
    image: clinicImg,
    cover:
      "radial-gradient(120% 80% at 10% 90%, rgba(244,63,94,0.28), transparent 60%), radial-gradient(80% 80% at 90% 10%, rgba(94,234,212,0.28), transparent 60%), linear-gradient(180deg,#181008 0%, #0a1a16 100%)",
    liveUrl: "#",
    problem:
      "Patients missed appointments and struggled to reach the clinic for follow-ups and prescription refills.",
    goal: "Give patients a lightweight app for bookings and reminders, and give staff a simple queue view.",
    solution:
      "Shipped iOS + Android apps with appointment booking, push reminders, prescription history, and a staff-side queue dashboard.",
    features: [
      "Appointment booking and rescheduling",
      "Push notification reminders",
      "Prescription and visit history",
      "Staff queue and check-in view",
      "Secure auth with OTP",
    ],
    stack: ["React Native", "Expo", "Node.js", "PostgreSQL", "Firebase"],
    process: [
      "Shadowed reception staff for 2 days",
      "Rapid prototype tested with real patients",
      "Two-week beta before public rollout",
    ],
    challenges: [
      "Handling flaky rural connectivity gracefully",
      "Keeping the UI accessible for older patients",
    ],
    results: [
      { label: "No-show rate", value: "-48%" },
      { label: "Repeat bookings", value: "+2.1×" },
      { label: "Store rating", value: "4.8" },
    ],
    impact:
      "Dramatically reduced no-shows and freed up reception time for patient-facing work rather than phone calls.",
  },
];
